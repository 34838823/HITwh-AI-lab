import numpy as np
import pandas as pd
import os
from sklearn import tree
from sklearn.metrics import f1_score, accuracy_score, plot_confusion_matrix
from sklearn.model_selection import train_test_split
import graphviz
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import ConfusionMatrixDisplay, confusion_matrix
import matplotlib.pyplot as plt
from sklearn.model_selection import GridSearchCV


def get_feature(df, train_mode=True):
    # test_mode: 用于区分训练数据和测试数据，训练数据存在label而测试数据不存在label
    df = df.iloc[::-1]
    if (train_mode):
        df['type'] = df['type'].map({'拖网': 0, '围网': 1, '刺网': 2})
        # 将label由str类型转换为int类型
        label = np.array(df['type'].iloc[0])
        df = df.drop(['type'], axis=1)
    else:
        label = None
    features = np.array(
        [df['x'].std(), df['x'].mean(), df['x'].max(), df['x'].min(), df['y'].std(), df['y'].mean(), df['y'].max(),
         df['y'].min(), df['speed'].mean(), df['speed'].std(), df['speed'].max(), df['speed'].min(), df['direction'].mean(),
         df['direction'].std(), df['direction'].max(), df['direction'].min(),df['dis'].mean,df['dis'].std(),df['dis'].max(),df['dis'].min() ])
    return features, label


def load_data():  # 读入数据函数
    path = 'D:\学习资料\研究生课程\秋\人工智能原理及应用\作业\hy_round1_train_20200102\hy_round1_train_20200102'
    train_file = os.listdir(path)
    X = []
    Y = []
    for i, each in enumerate(train_file):
        if not i % 1000:  # 每读1000个文件输出一次
            print(i)
        each_path = os.path.join(path, each)
        df = pd.read_csv(each_path)
        x, y = get_feature(df)
        X.append(x)
        Y.append(y)
    X = np.array(X)
    Y = np.array(Y)
    np.save("./npy/x_array.npy", X)
    np.save("./npy/y_array.npy", Y)
    return X, Y


def eval(clf, X_train, X_test, y_train, y_test):
    """用于评估模型"""
    predicted = clf.predict(X_train)  # 训练集上进行模型预测
    accuracy = accuracy_score(y_train, predicted)
    print("训练集准确率", accuracy)
    f1 = f1_score(y_train, predicted, average='macro')
    print("训练集f1_score", f1)

    predicted = clf.predict(X_test)  # 测试集上进行模型预测
    accuracy = accuracy_score(y_test, predicted)
    print("测试集准确率", accuracy)
    f1 = f1_score(y_test, predicted, average='macro')
    print("测试集f1_score", f1)

    cm = confusion_matrix(y_test, predicted, labels=clf.classes_)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm,display_labels = clf.classes_).plot()
    plt.show()


def decision_tree():
    """决策树模型"""
    # 读入特征文件数据
    X = np.load("./npy/data_x2.npy")
    Y = np.load("./npy/data_y2.npy")
    # 把数据切分为训练集与测试两个部分，一般采用8:2或7:3比例
    # 使用sklearn决策树对部分数据进行分类
    # 在深度学习中跑一次模型可能会花很长的时间，这时候先使用部分数据既可以方便程序的debug，对模型运行时间有个大致的概念，并理解训练数据太少导致过拟合现象。

    # 切分数据集
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=0)
    # 模型构建，参数random_state用来设置分枝中的随机模式的参数，赋值为任意整数可以使模型在同一个训练集和测试集下稳定
    # 模型训练
    clf = tree.DecisionTreeClassifier(random_state=2021)
    clf = clf.fit(X_train, y_train)
    #可视化

    feature_name = ['x_std', 'x_mean', 'x_max', 'x_min', 'y_std', 'y_mean', 'y_max', 'y_min', 'speed_mean', 'speed_std',
                    'speed_max', 'speed_min',
                    'direction_mean', 'direction_std', 'direction_max', 'direction_min', 'dis_mean', 'dis_std',
                    'dis_max', 'dis_min']
    dot_data = tree.export_graphviz(clf, out_file=None, feature_names=feature_name, class_names=["0", "1", "2"],
                                    filled=True, rounded=True)
    graph = graphviz.Source(dot_data)
    graph.view()

    eval(clf, X_train, X_test, y_train, y_test)
    return clf


def forest_random():
    """随机森林"""
    X = np.load("./npy/data_x2.npy")
    Y = np.load("./npy/data_y2.npy")
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=0)
    # params = {'n_estimators': [100, 200, 500], 'max_depth': range(15, 20),
    # 'criterion': ['entropy', 'gini'], "class_weight": ['balanced'], "random_state": [2021], }
    # clf=RandomForestClassifier()
    # GS= GridSearchCV(clf, param_grid=params, cv=8, n_jobs=5, scoring="f1_macro")
    # GS.fit(X_train,y_train)
    # print(GS.best_params_)#选择参数,看哪些参数合适
    clf = RandomForestClassifier(n_estimators=500, max_depth=15, criterion='entropy', class_weight='balanced',
                                  random_state=2021);#填上选好的参数
    clf.fit(X_train, y_train)#训练
    feature_name = ['x_std', 'x_mean', 'x_max', 'x_min', 'y_std', 'y_mean', 'y_max', 'y_min', 'speed_mean', 'speed_std',
                    'speed_max', 'speed_min',
                    'direction_mean', 'direction_std', 'direction_max', 'direction_min', 'dis_mean', 'dis_std',
                    'dis_max', 'dis_min']
    eval(clf, X_train, X_test, y_train, y_test)


if __name__ == '__main__':
    # load_data()
    decision_tree()
    # forest_random()
