from __future__ import division

import numpy as np
import math
import matplotlib
import matplotlib.pyplot as plt

matplotlib.use('TkAgg')


# f(x)=x﹒sin(10π﹒x)+1.0的最大值,其中x∈[-1,2]。
def func(x):
    pi = math.pi
    a = math.sin(10 * pi * x)
    y = x * a + 1.0
    return y


def paint():
    x = np.linspace(-1, 2, 1000)
    y = [0 for i in range(1000)]
    for i in range(1000):
        y[i] = func(x[i])
    plt.plot(x, y, 'ro', label='func')
    plt.show()


def annealing():
    T = 0.4  # initiate temperature

    Tmin = 0.0004  # minimum value of terperature
    # Tmin = 20  # minimum value of terperature

    x = np.random.uniform(-1, 2)  # initiate x

    k = 1000  # times of internal circulation
    # k = 50  # times of internal circulation

    y = -100  # initiate result
    t = 0  # time

    while T >= Tmin:
        for i in range(k):
            # calculate y
            y = func(x)
            # generate a new x in the neighboorhood of x by transform function
            a = np.random.uniform(-0.3, 0.3)
            xNew = x + a * T * 10
            if (-1 <= xNew and xNew <= 2):
                yNew = func(xNew)
                if yNew - y > 0:
                    x = xNew
                else:
                    # metropolis principle
                    p = math.exp((yNew - y) / T)
                    r = np.random.uniform(0, 1)
                    if r < p:
                        x = xNew
        t += 1
        print("time:" + str(t), x, func(x), a)
        T = 0.95 * T  # 降温函数


if __name__ == '__main__':
    # paint()
    annealing()
