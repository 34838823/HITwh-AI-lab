import pandas as pd
import os
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression

path = r'D:\学习资料\研究生课程\秋\人工智能原理及应用\作业\hy_round1_train_20200102\hy_round1_train_20200102'

def test_case1(path):
    train_file = os.listdir(path)
    data = []
    for each in train_file:
        each_path = os.path.join(path, each)
        temp = pd.read_csv(each_path)[['渔船ID', 'x', 'y', '速度', '方向', 'time', 'type']]
        data.append(temp)
    train = pd.concat(data)
    train.rename(columns={'渔船ID': 'ID', '速度': 'speed', '方向': 'direction'}, inplace=True)

    train['type'] = train['type'].map({'拖网': 0, '围网': 1, '刺网': 2})
    train.head()
    train.describe()
    print(train.isnull().sum(), '\n\n', train['type'].value_counts())
    train.dropna(inplace=True)
    print(train.isnull().sum())

    f, [ax1, ax2] = plt.subplots(1, 2, figsize=(20, 10))
    train['type'].value_counts().plot.pie(autopct='%1.2f%%', ax=ax1)
    sns.countplot(x='type', data=train, ax=ax2)
    f.suptitle('Fishing type')
    plt.show()

    X_train = train[['ID', 'x', 'y', 'speed', 'direction']]
    Y_train = train[['type']]
    print(X_train.head())
    model = LinearRegression()  ##生成对象
    model.fit(X_train, Y_train)  ##进行回归拟合
    print(model.intercept_)
    print(model.coef_)

    train.groupby(['speed', 'type'])['type'].count()

    plt.figure(figsize=(20, 10))  ##构图
    sns.countplot(x='speed', hue='type', data=train)
    ax1.set_title('Speed -> type influence')

    interval = [0, 1, 5, 10, 20, 30, 50, 110]
    train['speed'] = pd.cut(train['speed'], interval, labels=['0', '1', '2', '3', '4', '5', '6'])
    train.groupby(['speed', 'type'])['type'].count()
    plt.figure(figsize=(20, 10))
    sns.countplot(x='speed', hue='type', data=train)
    ax1.set_title('Speed -> type influence')


if __name__ == '__main__':
    test_case1(path)
