import os
import numpy as np
import pandas as pd
import datetime
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split
from sklearn.metrics import f1_score, accuracy_score
from sklearn.svm import SVC
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay


def read_feat(path, test_mode=False):
    df = pd.read_csv(path)
    df = df.iloc[::-1]

    if test_mode:
        df['type'] = df['type'].map({'拖网': 0, '围网': 1, '刺网': 2})
        label = np.array(df['type'].iloc[0])
        df = df.drop(['type'], axis=1)
    else:
        label = None

    df['time'] = df['time'].apply(lambda x: datetime.datetime.strptime(x, "%m%d %H:%M:%S"))
    df_diff = df['time'].diff(1).iloc[1:]
    df_diff = df_diff.dt.total_seconds()
    df['dis'] = np.sqrt(df['x'] ** 2 + df['y'] ** 2)
    for column in list(df.columns[df.isnull().sum() > 0]):  # 去除含有空值的行
        mean_val = df[column].mean()
        df[column].fillna(mean_val, inplace=True)
    features = np.array([df['x'].std(), df['x'].mean(), df['x'].max(), df['x'].min(),
                         df['y'].std(), df['y'].mean(), df['y'].max(), df['y'].min(),
                         df['速度'].mean(), df['速度'].std(), df['速度'].max(), df['速度'].min(),
                         df['方向'].mean(), df['方向'].std(), df['方向'].max(), df['方向'].min(),
                         ])
    return (features, label) if len(features[np.isnan(features)]) == 0 else (None, None)


def load_data(X_file="./npy/data_x2.npy", Y_file="./npy/data_y2.npy", new=False):
    if os.path.exists(X_file) and os.path.exists(Y_file) and not new:
        X = np.load(X_file)
        Y = np.load(Y_file)
        return np.array(X), np.array(Y)
    else:
        path = 'D:\学习资料\研究生课程\秋\人工智能原理及应用\作业\hy_round1_train_20200102\hy_round1_train_20200102'
        train_file = os.listdir(path)
        X = []
        Y = []
        for i, each in enumerate(train_file):
            if not i % 1000:
                print(i)
            each_path = os.path.join(path, each)
            x, y = read_feat(each_path, True)
            if x is not None:
                X.append(x)
                Y.append(y)
        X = np.array(X)
        Y = np.array(Y)
        np.save(X_file, X)
        np.save(Y_file, Y)
        return X, Y


def svm_():
    """SVM方法"""
    # 按特定比例进行训练集切分
    X, Y = load_data()
    X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.2, random_state=0)
    # 将参数写成字典下形式
    parameters = [
        {
            # 'kernel': ['rbf'],
            # 'kernel': ['poly'],
            # 'kernel': ['linear'],
            'kernel': ['sigmoid'],
            'C': [100],
            # 'gamma': [0.1],
            'class_weight': ['balanced']
        }

    ]  # 调参数部分，根据kernel的不同，各参数的参数种类有所不同
    # 参数调优
    clf = GridSearchCV(estimator=SVC(), param_grid=parameters, cv=8, n_jobs=5, scoring='f1_macro')
    clf.fit(X_train, y_train)
    print("Best set score:{:.2f}".format(clf.best_score_))
    print("Best parameters:{}".format(clf.best_params_))
    print("Test set score:{:.2f}".format(clf.score(X_test, y_test)))

    predicted = clf.predict(X_test)  # 模型预测
    accuracy = accuracy_score(y_test, predicted)
    print("accuracy", accuracy)
    print("f1_score", f1_score(y_test, predicted, labels=[0, 1, 2], average='macro'))
    # ConfusionMatrixDisplay.from_estimator(clf, X_test, y_test, labels=clf.classes_, cmap="GnBu")
    # plt.show()


if __name__ == '__main__':
    svm_()
